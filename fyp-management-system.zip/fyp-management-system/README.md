# FYP Management System — MERN Stack
Complete Final Year Project Management System

## Quick Start

### Step 1 — Backend
```bash
cd backend
npm install
```

### Step 2 — Create Admin Account (run once)
```bash
npm run seed
```
Admin credentials:
- **Email:** admin@fyp.com
- **Password:** Admin@123

### Step 3 — Start Backend
```bash
npm run dev
```
Runs on: http://localhost:5000

### Step 4 — Frontend
```bash
cd frontend
npm install
npm start
```
Runs on: http://localhost:3000

---

## Roles & Features

### Student
- Register → select "Student"
- Submit project proposal (title, domain, description, technologies, team)
- Edit proposal (while pending)
- View project status & supervisor feedback
- Upload weekly progress updates

### Supervisor
- Register → select "Supervisor" (or admin creates account)
- View assigned projects
- Approve / Reject proposals
- Mark project as In Progress / Completed
- Add feedback/comments to students
- Monitor weekly progress

### Admin
- Login: admin@fyp.com / Admin@123
- View all projects with search & filter
- Assign supervisors to projects
- Manage student accounts (edit/delete)
- Manage supervisor accounts (edit/delete)
- Delete projects

---

## API Routes

### Auth `/api/auth`
| Method | Route | Access |
|--------|-------|--------|
| POST | /register | Public |
| POST | /login | Public |
| GET | /me | Protected |

### Projects `/api/projects`
| Method | Route | Access |
|--------|-------|--------|
| POST | /submit | Student |
| GET | /mine | Student |
| PUT | /mine/edit | Student |
| GET | /assigned | Supervisor |
| PUT | /:id/status | Supervisor |
| POST | /:id/feedback | Supervisor |
| GET | /all | Admin |
| PUT | /:id/assign-supervisor | Admin |
| DELETE | /:id | Admin |

### Progress `/api/progress`
| Method | Route | Access |
|--------|-------|--------|
| POST | /upload | Student |
| GET | /mine | Student |
| GET | /:id | Supervisor/Admin |

### Admin `/api/admin`
| Method | Route | Access |
|--------|-------|--------|
| GET | /students | Admin |
| GET | /supervisors | Admin |
| DELETE | /users/:id | Admin |
| PUT | /users/:id | Admin |

---

## Tech Stack
- **Frontend:** React.js, React Router, Axios
- **Backend:** Node.js, Express.js
- **Database:** MongoDB (Mongoose)
- **Auth:** JWT, bcrypt
- **Styling:** Custom CSS (Inter font)
