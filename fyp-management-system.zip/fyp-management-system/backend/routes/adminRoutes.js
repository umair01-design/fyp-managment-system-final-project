import express from "express";
import protect from "../middleware/authMiddleware.js";
import authorizeRoles from "../middleware/roleMiddleware.js";
import { getStudents, getSupervisors, deleteUser, updateUser } from "../controllers/adminController.js";

const router = express.Router();

router.get("/students",    protect, authorizeRoles("admin"), getStudents);
router.get("/supervisors", protect, authorizeRoles("admin"), getSupervisors);
router.delete("/users/:id",protect, authorizeRoles("admin"), deleteUser);
router.put("/users/:id",   protect, authorizeRoles("admin"), updateUser);

export default router;
