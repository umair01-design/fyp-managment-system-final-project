import express from "express";
import protect from "../middleware/authMiddleware.js";
import authorizeRoles from "../middleware/roleMiddleware.js";
import {
    submitProposal, getMyProject, editProject,
    getAssignedProjects, updateProjectStatus, addFeedback,
    getAllProjects, assignSupervisor, deleteProject
} from "../controllers/projectController.js";

const router = express.Router();

// Student
router.post("/submit",   protect, authorizeRoles("student"), submitProposal);
router.get("/mine",      protect, authorizeRoles("student"), getMyProject);
router.put("/mine/edit", protect, authorizeRoles("student"), editProject);

// Supervisor
router.get("/assigned",             protect, authorizeRoles("supervisor"), getAssignedProjects);
router.put("/:id/status",           protect, authorizeRoles("supervisor"), updateProjectStatus);
router.post("/:id/feedback",        protect, authorizeRoles("supervisor"), addFeedback);

// Admin
router.get("/all",                  protect, authorizeRoles("admin"), getAllProjects);
router.put("/:id/assign-supervisor",protect, authorizeRoles("admin"), assignSupervisor);
router.delete("/:id",               protect, authorizeRoles("admin"), deleteProject);

export default router;
