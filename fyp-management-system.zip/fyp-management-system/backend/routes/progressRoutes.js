import express from "express";
import protect from "../middleware/authMiddleware.js";
import authorizeRoles from "../middleware/roleMiddleware.js";
import { uploadProgress, getMyProgress, getProgressByProject } from "../controllers/progressController.js";

const router = express.Router();

router.post("/upload",       protect, authorizeRoles("student"),    uploadProgress);
router.get("/mine",          protect, authorizeRoles("student"),    getMyProgress);
router.get("/:id",           protect, authorizeRoles("supervisor", "admin"), getProgressByProject);

export default router;
