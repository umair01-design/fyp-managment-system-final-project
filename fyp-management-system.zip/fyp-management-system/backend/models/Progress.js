import mongoose from "mongoose";

const progressSchema = new mongoose.Schema({
    project:     { type: mongoose.Schema.Types.ObjectId, ref: "Project", required: true },
    student:     { type: mongoose.Schema.Types.ObjectId, ref: "User",    required: true },
    studentName: { type: String },
    weekNumber:  { type: Number, required: true },
    description: { type: String, required: true },
    achievement: { type: String },
    nextPlan:    { type: String },
}, { timestamps: true });

const Progress = mongoose.model("Progress", progressSchema);
export default Progress;
