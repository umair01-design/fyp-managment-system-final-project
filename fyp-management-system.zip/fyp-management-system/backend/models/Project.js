import mongoose from "mongoose";

const feedbackSchema = new mongoose.Schema({
    supervisorId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    supervisorName: String,
    comment: { type: String, required: true },
    createdAt: { type: Date, default: Date.now }
});

const projectSchema = new mongoose.Schema({
    title:        { type: String, required: true },
    domain:       { type: String, required: true },
    description:  { type: String, required: true },
    technologies: { type: String, required: true },
    teamMembers:  { type: String, required: true },
    student:      { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    studentName:  { type: String },
    supervisor:   { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    supervisorName: { type: String, default: null },
    status:       { type: String, enum: ["pending", "approved", "rejected", "in-progress", "completed"], default: "pending" },
    feedback:     [feedbackSchema],
}, { timestamps: true });

const Project = mongoose.model("Project", projectSchema);
export default Project;
