import User from "../models/User.js";

// Get all students
export const getStudents = async (req, res) => {
    try {
        const students = await User.find({ role: "student" }).select("-password");
        res.json(students);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Get all supervisors
export const getSupervisors = async (req, res) => {
    try {
        const supervisors = await User.find({ role: "supervisor" }).select("-password");
        res.json(supervisors);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Delete user
export const deleteUser = async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ message: "User not found." });
        if (user.role === "admin") return res.status(400).json({ message: "Cannot delete admin." });
        await User.findByIdAndDelete(req.params.id);
        res.json({ message: "User deleted successfully." });
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Update user name/email
export const updateUser = async (req, res) => {
    try {
        const { name, email } = req.body;
        const user = await User.findByIdAndUpdate(
            req.params.id,
            { name, email },
            { new: true }
        ).select("-password");
        res.json(user);
    } catch (err) { res.status(500).json({ message: err.message }); }
};
