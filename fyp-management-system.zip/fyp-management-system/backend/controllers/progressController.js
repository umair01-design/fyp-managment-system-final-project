import Progress from "../models/Progress.js";
import Project from "../models/Project.js";
import User from "../models/User.js";

// Student: Upload weekly progress
export const uploadProgress = async (req, res) => {
    try {
        const { weekNumber, description, achievement, nextPlan } = req.body;
        if (!weekNumber || !description)
            return res.status(400).json({ message: "Week number and description are required." });

        const project = await Project.findOne({ student: req.user.id });
        if (!project) return res.status(404).json({ message: "No project found. Submit a proposal first." });
        if (project.status === "pending" || project.status === "rejected")
            return res.status(400).json({ message: "Your project must be approved before uploading progress." });

        const student = await User.findById(req.user.id);
        const progress = await Progress.create({
            project: project._id,
            student: req.user.id,
            studentName: student.name,
            weekNumber: Number(weekNumber),
            description,
            achievement: achievement || "",
            nextPlan:    nextPlan    || "",
        });
        res.status(201).json(progress);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Student / Supervisor: Get progress for own project
export const getMyProgress = async (req, res) => {
    try {
        const project = await Project.findOne({ student: req.user.id });
        if (!project) return res.status(404).json({ message: "No project found." });

        const updates = await Progress.find({ project: project._id }).sort({ weekNumber: 1 });
        res.json(updates);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Supervisor: Get progress for specific project
export const getProgressByProject = async (req, res) => {
    try {
        const updates = await Progress.find({ project: req.params.id }).sort({ weekNumber: 1 });
        res.json(updates);
    } catch (err) { res.status(500).json({ message: err.message }); }
};
