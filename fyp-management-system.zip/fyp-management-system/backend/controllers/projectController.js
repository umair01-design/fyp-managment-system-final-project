import Project from "../models/Project.js";
import User from "../models/User.js";

// Student: Submit proposal
export const submitProposal = async (req, res) => {
    try {
        const { title, domain, description, technologies, teamMembers } = req.body;
        if (!title || !domain || !description || !technologies || !teamMembers)
            return res.status(400).json({ message: "All fields are required." });

        const existing = await Project.findOne({ student: req.user.id });
        if (existing)
            return res.status(400).json({ message: "You have already submitted a proposal. Edit it instead." });

        const student = await User.findById(req.user.id);
        const project = await Project.create({
            title, domain, description, technologies, teamMembers,
            student: req.user.id,
            studentName: student.name,
        });
        res.status(201).json(project);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Student: Get own project
export const getMyProject = async (req, res) => {
    try {
        const project = await Project.findOne({ student: req.user.id });
        if (!project) return res.status(404).json({ message: "No project found." });
        res.json(project);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Student: Edit project (only if pending)
export const editProject = async (req, res) => {
    try {
        const project = await Project.findOne({ student: req.user.id });
        if (!project) return res.status(404).json({ message: "No project found." });
        if (project.status === "approved")
            return res.status(400).json({ message: "Approved projects cannot be edited." });

        const { title, domain, description, technologies, teamMembers } = req.body;
        if (title)       project.title       = title;
        if (domain)      project.domain      = domain;
        if (description) project.description = description;
        if (technologies) project.technologies = technologies;
        if (teamMembers) project.teamMembers  = teamMembers;

        await project.save();
        res.json(project);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Supervisor: Get assigned projects
export const getAssignedProjects = async (req, res) => {
    try {
        const projects = await Project.find({ supervisor: req.user.id });
        res.json(projects);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Supervisor: Approve or reject
export const updateProjectStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        if (!["approved","rejected","in-progress","completed"].includes(status))
            return res.status(400).json({ message: "Invalid status." });

        const project = await Project.findById(id);
        if (!project) return res.status(404).json({ message: "Project not found." });
        if (project.supervisor?.toString() !== req.user.id)
            return res.status(403).json({ message: "Not your assigned project." });

        project.status = status;
        await project.save();
        res.json(project);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Supervisor: Add feedback
export const addFeedback = async (req, res) => {
    try {
        const { id } = req.params;
        const { comment } = req.body;
        if (!comment) return res.status(400).json({ message: "Comment is required." });

        const project = await Project.findById(id);
        if (!project) return res.status(404).json({ message: "Project not found." });
        if (project.supervisor?.toString() !== req.user.id)
            return res.status(403).json({ message: "Not your assigned project." });

        const supervisor = await User.findById(req.user.id);
        project.feedback.push({ supervisorId: req.user.id, supervisorName: supervisor.name, comment });
        await project.save();
        res.json(project);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Admin: Get all projects
export const getAllProjects = async (req, res) => {
    try {
        const projects = await Project.find().sort({ createdAt: -1 });
        res.json(projects);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Admin: Assign supervisor
export const assignSupervisor = async (req, res) => {
    try {
        const { id } = req.params;
        const { supervisorId } = req.body;

        const project = await Project.findById(id);
        if (!project) return res.status(404).json({ message: "Project not found." });

        const supervisor = await User.findById(supervisorId);
        if (!supervisor || supervisor.role !== "supervisor")
            return res.status(400).json({ message: "Invalid supervisor." });

        project.supervisor     = supervisorId;
        project.supervisorName = supervisor.name;
        await project.save();
        res.json(project);
    } catch (err) { res.status(500).json({ message: err.message }); }
};

// Admin: Delete project
export const deleteProject = async (req, res) => {
    try {
        await Project.findByIdAndDelete(req.params.id);
        res.json({ message: "Project deleted." });
    } catch (err) { res.status(500).json({ message: err.message }); }
};
