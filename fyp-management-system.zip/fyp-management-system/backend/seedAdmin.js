/**
 * Admin Seeder Script
 * Run: node seedAdmin.js
 * Creates a default admin account if one does not exist.
 */

import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import User from "./models/User.js";

dotenv.config();

const ADMIN_EMAIL    = "admin@fyp.com";
const ADMIN_PASSWORD = "Admin@123";
const ADMIN_NAME     = "System Admin";

async function seedAdmin() {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("Connected to MongoDB ✅");

        const existing = await User.findOne({ email: ADMIN_EMAIL });

        if (existing) {
            console.log("Admin already exists:", ADMIN_EMAIL);
            console.log("Role:", existing.role);
        } else {
            const hashed = await bcrypt.hash(ADMIN_PASSWORD, 12);
            await User.create({
                name:     ADMIN_NAME,
                email:    ADMIN_EMAIL,
                password: hashed,
                role:     "admin",
            });
            console.log("✅ Admin created successfully!");
            console.log("Email   :", ADMIN_EMAIL);
            console.log("Password:", ADMIN_PASSWORD);
        }
    } catch (err) {
        console.error("Error:", err.message);
    } finally {
        await mongoose.disconnect();
        console.log("Done.");
    }
}

seedAdmin();
