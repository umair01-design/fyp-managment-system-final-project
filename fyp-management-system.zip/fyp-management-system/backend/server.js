import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import connectDB from "./config/db.js";
import authRoutes     from "./routes/authRoutes.js";
import projectRoutes  from "./routes/projectRoutes.js";
import progressRoutes from "./routes/progressRoutes.js";
import adminRoutes    from "./routes/adminRoutes.js";
import errorHandler   from "./middleware/errorMiddleware.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/auth",     authRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/progress", progressRoutes);
app.use("/api/admin",    adminRoutes);

app.get("/", (req, res) => res.send("FYP Management API running 🚀"));
app.use(errorHandler);

connectDB().then(() => {
    app.listen(process.env.PORT || 5000, () =>
        console.log(`Server running on port ${process.env.PORT || 5000} 🚀`)
    );
});
