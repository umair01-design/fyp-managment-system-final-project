import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useAuth } from "./context/AuthContext";

import Navbar    from "./components/Navbar";
import Footer    from "./components/Footer";
import Sidebar   from "./components/Sidebar";
import ProtectedRoute from "./components/ProtectedRoute";

import Home               from "./pages/Home";
import Login              from "./pages/Login";
import Register           from "./pages/Register";

import StudentDashboard   from "./pages/StudentDashboard";
import SubmitProposal     from "./pages/SubmitProposal";
import MyProject          from "./pages/MyProject";
import WeeklyProgress     from "./pages/WeeklyProgress";

import SupervisorDashboard from "./pages/SupervisorDashboard";
import ProjectReview       from "./pages/ProjectReview";

import AdminDashboard     from "./pages/AdminDashboard";
import AllProjects        from "./pages/AllProjects";
import ManageStudents     from "./pages/ManageStudents";
import ManageSupervisors  from "./pages/ManageSupervisors";

import Profile   from "./pages/Profile";
import Settings  from "./pages/Settings";

import "./App.css";

const DashboardLayout = ({ children }) => (
    <div className="layout">
        <Sidebar />
        <div className="main-content">{children}</div>
    </div>
);

function App() {
    const { user } = useAuth();
    const isLoggedIn = !!user;

    return (
        <BrowserRouter>
            <Navbar />
            <Routes>
                {/* Public */}
                <Route path="/"         element={<Home />} />
                <Route path="/login"    element={<Login />} />
                <Route path="/register" element={<Register />} />

                {/* Student */}
                <Route path="/student" element={
                    <ProtectedRoute role="student">
                        <DashboardLayout><StudentDashboard /></DashboardLayout>
                    </ProtectedRoute>
                }/>
                <Route path="/submit-proposal" element={
                    <ProtectedRoute role="student">
                        <DashboardLayout><SubmitProposal /></DashboardLayout>
                    </ProtectedRoute>
                }/>
                <Route path="/my-project" element={
                    <ProtectedRoute role="student">
                        <DashboardLayout><MyProject /></DashboardLayout>
                    </ProtectedRoute>
                }/>
                <Route path="/weekly-progress" element={
                    <ProtectedRoute role="student">
                        <DashboardLayout><WeeklyProgress /></DashboardLayout>
                    </ProtectedRoute>
                }/>

                {/* Supervisor */}
                <Route path="/supervisor" element={
                    <ProtectedRoute role="supervisor">
                        <DashboardLayout><SupervisorDashboard /></DashboardLayout>
                    </ProtectedRoute>
                }/>
                <Route path="/project-review/:id" element={
                    <ProtectedRoute role="supervisor">
                        <DashboardLayout><ProjectReview /></DashboardLayout>
                    </ProtectedRoute>
                }/>

                {/* Admin */}
                <Route path="/admin" element={
                    <ProtectedRoute role="admin">
                        <DashboardLayout><AdminDashboard /></DashboardLayout>
                    </ProtectedRoute>
                }/>
                <Route path="/all-projects" element={
                    <ProtectedRoute role="admin">
                        <DashboardLayout><AllProjects /></DashboardLayout>
                    </ProtectedRoute>
                }/>
                <Route path="/manage-students" element={
                    <ProtectedRoute role="admin">
                        <DashboardLayout><ManageStudents /></DashboardLayout>
                    </ProtectedRoute>
                }/>
                <Route path="/manage-supervisors" element={
                    <ProtectedRoute role="admin">
                        <DashboardLayout><ManageSupervisors /></DashboardLayout>
                    </ProtectedRoute>
                }/>

                {/* Shared */}
                <Route path="/profile" element={
                    <ProtectedRoute>
                        <DashboardLayout><Profile /></DashboardLayout>
                    </ProtectedRoute>
                }/>
                <Route path="/settings" element={
                    <ProtectedRoute>
                        <DashboardLayout><Settings /></DashboardLayout>
                    </ProtectedRoute>
                }/>
            </Routes>
            {!isLoggedIn && <Footer />}
        </BrowserRouter>
    );
}
export default App;
