import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { submitProposal } from "../services/authService";

const DOMAINS = ["Artificial Intelligence", "Web Development", "Mobile App", "Cybersecurity", "Data Science", "IoT", "Cloud Computing", "Blockchain", "Other"];

function SubmitProposal() {
    const navigate = useNavigate();
    const [form, setForm] = useState({ title:"", domain:"", description:"", technologies:"", teamMembers:"" });
    const [error,   setError]   = useState("");
    const [loading, setLoading] = useState(false);

    const handleChange = e => setForm({...form, [e.target.name]: e.target.value});

    const handleSubmit = async e => {
        e.preventDefault();
        setError("");
        const { title, domain, description, technologies, teamMembers } = form;
        if (!title || !domain || !description || !technologies || !teamMembers)
            return setError("All fields are required.");
        if (description.length < 50)
            return setError("Description must be at least 50 characters.");

        setLoading(true);
        try {
            await submitProposal(form);
            navigate("/student");
        } catch (err) {
            setError(err.response?.data?.message || "Submission failed.");
        } finally { setLoading(false); }
    };

    return (
        <div className="page-wrapper">
            <div className="form-card">
                <div className="form-card-header">
                    <h1>Submit Project Proposal</h1>
                    <p>Fill in the details of your Final Year Project</p>
                </div>

                {error && <div className="error">⚠️ {error}</div>}

                <form onSubmit={handleSubmit}>
                    <div className="input-group">
                        <label>Project Title <span className="required">*</span></label>
                        <input type="text" name="title" placeholder="e.g. AI-Based Student Attendance System"
                            value={form.title} onChange={handleChange} />
                    </div>

                    <div className="input-group">
                        <label>Project Domain <span className="required">*</span></label>
                        <select name="domain" value={form.domain} onChange={handleChange}>
                            <option value="">— Select Domain —</option>
                            {DOMAINS.map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                    </div>

                    <div className="input-group">
                        <label>Project Description <span className="required">*</span>
                            <span className="field-hint">(min. 50 characters)</span></label>
                        <textarea name="description" rows="5"
                            placeholder="Describe your project objectives, scope, and expected outcomes..."
                            value={form.description} onChange={handleChange} />
                        <span className="char-count">{form.description.length} characters</span>
                    </div>

                    <div className="input-group">
                        <label>Technologies Used <span className="required">*</span></label>
                        <input type="text" name="technologies" placeholder="e.g. React.js, Node.js, MongoDB, Express"
                            value={form.technologies} onChange={handleChange} />
                    </div>

                    <div className="input-group">
                        <label>Team Members <span className="required">*</span></label>
                        <input type="text" name="teamMembers" placeholder="e.g. Ali Khan (21-CS-001), Sara Ahmed (21-CS-045)"
                            value={form.teamMembers} onChange={handleChange} />
                    </div>

                    <div className="form-actions">
                        <button type="button" className="btn-cancel" onClick={() => navigate("/student")}>Cancel</button>
                        <button type="submit" className="btn-primary" disabled={loading}>
                            {loading ? "Submitting..." : "Submit Proposal →"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default SubmitProposal;
