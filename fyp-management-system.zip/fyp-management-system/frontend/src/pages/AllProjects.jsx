import { useState, useEffect } from "react";
import { getAllProjects, getSupervisors, assignSupervisor, deleteProject } from "../services/authService";

const statusColor = { pending:"badge-yellow", approved:"badge-green", rejected:"badge-red", "in-progress":"badge-blue", completed:"badge-green" };

function AllProjects() {
    const [projects,    setProjects]    = useState([]);
    const [supervisors, setSupervisors] = useState([]);
    const [search,      setSearch]      = useState("");
    const [statusFilter,setStatusFilter]= useState("all");
    const [error,  setError]  = useState("");
    const [success,setSuccess]= useState("");
    const [loading,setLoading]= useState(true);

    useEffect(() => {
        Promise.all([getAllProjects(), getSupervisors()])
            .then(([p, s]) => { setProjects(p.data); setSupervisors(s.data); })
            .catch(()=>{}).finally(()=>setLoading(false));
    }, []);

    const handleAssign = async (projectId, supervisorId) => {
        if (!supervisorId) return;
        setError(""); setSuccess("");
        try {
            const r = await assignSupervisor(projectId, { supervisorId });
            setProjects(prev => prev.map(p => p._id === projectId ? r.data : p));
            setSuccess("Supervisor assigned successfully!");
        } catch (err) { setError(err.response?.data?.message || "Failed."); }
    };

    const handleDelete = async (id) => {
        if (!window.confirm("Delete this project?")) return;
        try {
            await deleteProject(id);
            setProjects(prev => prev.filter(p => p._id !== id));
            setSuccess("Project deleted.");
        } catch (err) { setError("Delete failed."); }
    };

    const filtered = projects
        .filter(p => statusFilter === "all" || p.status === statusFilter)
        .filter(p => p.title.toLowerCase().includes(search.toLowerCase()) ||
                     (p.studentName||"").toLowerCase().includes(search.toLowerCase()));

    if (loading) return <div className="page-loading">Loading...</div>;

    return (
        <div className="page-wrapper">
            <div className="page-header">
                <div><h1>All Projects</h1><p className="page-subtitle">{projects.length} total submissions</p></div>
            </div>

            {error   && <div className="error">⚠️ {error}</div>}
            {success && <div className="success-msg">✅ {success}</div>}

            <div className="filter-bar">
                <input type="text" placeholder="🔍 Search by title or student..." value={search} onChange={e=>setSearch(e.target.value)} className="search-input" />
                <select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)} className="filter-select">
                    <option value="all">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                    <option value="in-progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>

            <div className="table-wrapper">
                <table>
                    <thead><tr><th>#</th><th>Project Title</th><th>Student</th><th>Domain</th><th>Status</th><th>Assign Supervisor</th><th>Action</th></tr></thead>
                    <tbody>
                        {filtered.length === 0 ? (
                            <tr><td colSpan="7" style={{textAlign:"center",padding:"30px",color:"#94a3b8"}}>No projects found.</td></tr>
                        ) : filtered.map((p, i) => (
                            <tr key={p._id}>
                                <td>{i+1}</td>
                                <td><strong>{p.title}</strong><br/><span style={{fontSize:"12px",color:"#94a3b8"}}>{p.domain}</span></td>
                                <td>{p.studentName}</td>
                                <td>{p.domain}</td>
                                <td><span className={`badge ${statusColor[p.status]}`}>{p.status}</span></td>
                                <td>
                                    <select className="inline-select"
                                        value={p.supervisor || ""}
                                        onChange={e => handleAssign(p._id, e.target.value)}>
                                        <option value="">— Assign —</option>
                                        {supervisors.map(s => <option key={s._id} value={s._id}>{s.name}</option>)}
                                    </select>
                                    {p.supervisorName && <span style={{fontSize:"12px",color:"#2563eb",display:"block",marginTop:"4px"}}>✓ {p.supervisorName}</span>}
                                </td>
                                <td>
                                    <button className="btn-danger-sm" onClick={() => handleDelete(p._id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
export default AllProjects;
