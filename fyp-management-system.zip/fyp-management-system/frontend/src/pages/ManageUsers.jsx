import DashboardLayout from "../components/DashboardLayout";

const users = [
    { name: "Ali Hassan",   email: "ali@uni.edu",    role: "student",    status: "Active" },
    { name: "Usman Tariq",  email: "usman@uni.edu",  role: "student",    status: "Active" },
    { name: "Dr. Ahmed",    email: "ahmed@uni.edu",  role: "supervisor", status: "Active" },
    { name: "Dr. Sara",     email: "sara@uni.edu",   role: "supervisor", status: "Active" },
    { name: "Admin User",   email: "admin@uni.edu",  role: "admin",      status: "Active" },
];

function ManageUsers() {
    return (
        <DashboardLayout>
            <div className="dashboard-container">
                <div className="page-header">
                    <div>
                        <div className="page-badge">👥 Admin</div>
                        <h1>Manage Users</h1>
                        <p className="text-muted">Add, edit or remove system users.</p>
                    </div>
                    <button className="btn btn-primary btn-sm">+ Add User</button>
                </div>

                <div className="dashboard-section">
                    <h2>👥 All Users</h2>
                    <div className="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {users.map((u, i) => (
                                    <tr key={i}>
                                        <td className="text-muted">{i + 1}</td>
                                        <td><strong>{u.name}</strong></td>
                                        <td className="text-muted">{u.email}</td>
                                        <td>
                                            <span className={`badge ${
                                                u.role === "admin"      ? "badge-red"    :
                                                u.role === "supervisor" ? "badge-yellow" :
                                                "badge-blue"
                                            }`}>
                                                {u.role}
                                            </span>
                                        </td>
                                        <td>
                                            <span className="badge badge-green">{u.status}</span>
                                        </td>
                                        <td>
                                            <div style={{ display: "flex", gap: "8px" }}>
                                                <button className="btn btn-ghost btn-sm">Edit</button>
                                                <button className="btn btn-sm" style={{ background: "#fee2e2", color: "#991b1b" }}>Delete</button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}

export default ManageUsers;
