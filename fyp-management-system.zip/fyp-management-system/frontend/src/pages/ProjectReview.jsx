import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getAssignedProjects, updateProjectStatus, addFeedback, getProgressByProject } from "../services/authService";

const statusColor = { pending:"badge-yellow", approved:"badge-green", rejected:"badge-red", "in-progress":"badge-blue", completed:"badge-green" };

function ProjectReview() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [project,  setProject]  = useState(null);
    const [progress, setProgress] = useState([]);
    const [comment,  setComment]  = useState("");
    const [error,    setError]    = useState("");
    const [success,  setSuccess]  = useState("");
    const [loading,  setLoading]  = useState(true);

    useEffect(() => {
        Promise.all([
            getAssignedProjects(),
            getProgressByProject(id).catch(() => ({ data: [] }))
        ]).then(([proj, prog]) => {
            const found = proj.data.find(p => p._id === id);
            if (!found) navigate("/supervisor");
            setProject(found);
            setProgress(prog.data);
            setLoading(false);
        });
    }, [id]);

    const handleStatus = async (status) => {
        setError(""); setSuccess("");
        try {
            const r = await updateProjectStatus(id, { status });
            setProject(r.data);
            setSuccess(`Project marked as "${status}".`);
        } catch (err) { setError(err.response?.data?.message || "Failed."); }
    };

    const handleFeedback = async e => {
        e.preventDefault();
        setError(""); setSuccess("");
        if (!comment.trim()) return setError("Comment cannot be empty.");
        try {
            const r = await addFeedback(id, { comment });
            setProject(r.data); setComment("");
            setSuccess("Feedback added successfully!");
        } catch (err) { setError(err.response?.data?.message || "Failed."); }
    };

    if (loading) return <div className="page-loading">Loading...</div>;
    if (!project) return null;

    return (
        <div className="page-wrapper">
            <button className="btn-back" onClick={() => navigate("/supervisor")}>← Back to Dashboard</button>

            <div className="detail-card">
                <div className="detail-card-header">
                    <div><h1>{project.title}</h1><p className="page-subtitle">Student: {project.studentName}</p></div>
                    <span className={`badge badge-lg ${statusColor[project.status]}`}>{project.status}</span>
                </div>
                <div className="detail-grid">
                    <div className="detail-item"><label>Domain</label><span>{project.domain}</span></div>
                    <div className="detail-item"><label>Technologies</label><span>{project.technologies}</span></div>
                    <div className="detail-item"><label>Team Members</label><span>{project.teamMembers}</span></div>
                    <div className="detail-item full-width"><label>Description</label><span>{project.description}</span></div>
                </div>

                {error   && <div className="error" style={{margin:"16px 0"}}>⚠️ {error}</div>}
                {success && <div className="success-msg" style={{margin:"16px 0"}}>✅ {success}</div>}

                <div className="action-bar">
                    <h3>Update Status</h3>
                    <div className="status-buttons">
                        {project.status === "pending" && <>
                            <button className="btn-success" onClick={() => handleStatus("approved")}>✅ Approve</button>
                            <button className="btn-danger"  onClick={() => handleStatus("rejected")}>❌ Reject</button>
                        </>}
                        {(project.status === "approved") &&
                            <button className="btn-primary" onClick={() => handleStatus("in-progress")}>🔄 Mark In Progress</button>}
                        {project.status === "in-progress" &&
                            <button className="btn-success" onClick={() => handleStatus("completed")}>🏆 Mark Completed</button>}
                    </div>
                </div>
            </div>

            <div className="two-col-layout" style={{marginTop:"24px"}}>
                <div className="form-card">
                    <div className="form-card-header"><h2>Add Feedback</h2><p>Provide comments to the student</p></div>
                    <form onSubmit={handleFeedback}>
                        <div className="input-group">
                            <textarea rows="4" placeholder="Write your feedback or comments here..."
                                value={comment} onChange={e => setComment(e.target.value)} />
                        </div>
                        <button type="submit" className="btn-primary" style={{width:"100%"}}>Submit Feedback →</button>
                    </form>

                    {project.feedback?.length > 0 && (
                        <div style={{marginTop:"20px"}}>
                            <h3 style={{marginBottom:"12px"}}>Previous Feedback</h3>
                            {project.feedback.map((f, i) => (
                                <div key={i} className="feedback-card">
                                    <div className="feedback-header"><strong>You</strong><span>{new Date(f.createdAt).toLocaleDateString()}</span></div>
                                    <p>{f.comment}</p>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div className="updates-panel">
                    <h2>Student Progress ({progress.length} updates)</h2>
                    {progress.length === 0 ? (
                        <div className="empty-state-sm"><p>No progress submitted yet.</p></div>
                    ) : (
                        <div className="update-list">
                            {progress.map(u => (
                                <div key={u._id} className="update-card">
                                    <div className="update-week-badge">Week {u.weekNumber}</div>
                                    <p className="update-desc">{u.description}</p>
                                    {u.achievement && <p className="update-sub"><strong>✅</strong> {u.achievement}</p>}
                                    {u.nextPlan    && <p className="update-sub"><strong>📌</strong> {u.nextPlan}</p>}
                                    <span className="update-date">{new Date(u.createdAt).toLocaleDateString()}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default ProjectReview;
