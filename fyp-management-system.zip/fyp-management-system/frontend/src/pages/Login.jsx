import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginUser } from "../services/authService";
import { useAuth } from "../context/AuthContext";

function Login() {
    const [email,    setEmail]    = useState("");
    const [password, setPassword] = useState("");
    const [error,    setError]    = useState("");
    const [loading,  setLoading]  = useState(false);

    const { login }   = useAuth();
    const navigate    = useNavigate();

    const validate = () => {
        if (!email.trim())    return "Email address is required.";
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) return "Please enter a valid email address.";
        if (!password)        return "Password is required.";
        if (password.length < 6) return "Password must be at least 6 characters.";
        return null;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        const validationError = validate();
        if (validationError) { setError(validationError); return; }

        setLoading(true);
        try {
            const res = await loginUser({ email: email.toLowerCase(), password });
            login(res.data);

            if (res.data.role === "student")    navigate("/student");
            else if (res.data.role === "supervisor") navigate("/supervisor");
            else if (res.data.role === "admin")      navigate("/admin");
            else navigate("/");
        } catch (err) {
            setError(err.response?.data?.message || "Login failed. Please check your credentials.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-container">
            <form className="auth-form" onSubmit={handleSubmit}>
                <div className="auth-logo">
                    <div className="auth-logo-icon">🎓</div>
                    <h2>Welcome Back</h2>
                    <p className="auth-subtitle">Sign in to your FYP account</p>
                </div>

                {error && <div className="error">⚠️ {error}</div>}

                <div className="input-group">
                    <label>Email Address</label>
                    <input
                        type="email"
                        placeholder="you@university.edu"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>

                <div className="input-group">
                    <label>Password</label>
                    <input
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>

                <button type="submit" disabled={loading}>
                    {loading ? "Signing in..." : "Sign In →"}
                </button>

                <p className="auth-link">
                    Don't have an account? <Link to="/register">Register here</Link>
                </p>
            </form>
        </div>
    );
}

export default Login;
