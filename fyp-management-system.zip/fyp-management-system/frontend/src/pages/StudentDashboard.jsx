import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getMyProject, getMyProgress } from "../services/authService";
import { useAuth } from "../context/AuthContext";

function StudentDashboard() {
    const { user } = useAuth();
    const [project,  setProject]  = useState(null);
    const [progress, setProgress] = useState([]);
    const [loading,  setLoading]  = useState(true);

    useEffect(() => {
        Promise.all([
            getMyProject().catch(() => null),
            getMyProgress().catch(() => [])
        ]).then(([proj, prog]) => {
            setProject(proj?.data || null);
            setProgress(prog?.data || []);
            setLoading(false);
        });
    }, []);

    const statusColor = { pending:"badge-yellow", approved:"badge-green", rejected:"badge-red", "in-progress":"badge-blue", completed:"badge-green" };

    if (loading) return <div className="page-loading">Loading dashboard...</div>;

    return (
        <div className="dashboard-container">
            <div className="page-header">
                <div>
                    <h1>Student Dashboard</h1>
                    <p className="page-subtitle">Welcome back, <strong>{user?.name}</strong></p>
                </div>
                {!project && <Link to="/submit-proposal" className="btn-primary">+ Submit Proposal</Link>}
            </div>

            <div className="dashboard-cards">
                <div className="card">
                    <div className="card-icon">📋</div>
                    <h3>Project Status</h3>
                    <p>{project ? <span className={`badge ${statusColor[project.status]}`}>{project.status}</span> : "—"}</p>
                </div>
                <div className="card">
                    <div className="card-icon">📅</div>
                    <h3>Weekly Updates</h3>
                    <p>{progress.length}</p>
                </div>
                <div className="card">
                    <div className="card-icon">💬</div>
                    <h3>Feedback Received</h3>
                    <p>{project?.feedback?.length || 0}</p>
                </div>
                <div className="card">
                    <div className="card-icon">👨‍🏫</div>
                    <h3>Supervisor</h3>
                    <p className="card-text-sm">{project?.supervisorName || "Not Assigned"}</p>
                </div>
            </div>

            {project ? (
                <div className="dashboard-section">
                    <h2>My Project</h2>
                    <div className="project-detail-grid">
                        <div className="project-detail-row"><span>Title</span><strong>{project.title}</strong></div>
                        <div className="project-detail-row"><span>Domain</span><strong>{project.domain}</strong></div>
                        <div className="project-detail-row"><span>Technologies</span><strong>{project.technologies}</strong></div>
                        <div className="project-detail-row"><span>Team</span><strong>{project.teamMembers}</strong></div>
                        <div className="project-detail-row"><span>Status</span><span className={`badge ${statusColor[project.status]}`}>{project.status}</span></div>
                    </div>
                    <div className="dash-action-row">
                        <Link to="/my-project" className="btn-secondary">View Full Details</Link>
                        {project.status === "pending" && <Link to="/my-project" className="btn-outline-sm">Edit Proposal</Link>}
                        <Link to="/weekly-progress" className="btn-primary">Upload Progress</Link>
                    </div>
                </div>
            ) : (
                <div className="empty-state">
                    <div className="empty-icon">📂</div>
                    <h3>No Project Submitted Yet</h3>
                    <p>Submit your FYP proposal to get started.</p>
                    <Link to="/submit-proposal" className="btn-primary" style={{marginTop:"16px"}}>Submit Proposal →</Link>
                </div>
            )}

            {progress.length > 0 && (
                <div className="dashboard-section" style={{marginTop:"24px"}}>
                    <h2>Recent Progress Updates</h2>
                    <div className="progress-list">
                        {progress.slice(-3).reverse().map(p => (
                            <div key={p._id} className="progress-item">
                                <div className="progress-week">Week {p.weekNumber}</div>
                                <div className="progress-desc">{p.description}</div>
                                <div className="progress-date">{new Date(p.createdAt).toLocaleDateString()}</div>
                            </div>
                        ))}
                    </div>
                    <Link to="/weekly-progress" className="btn-link">View All Updates →</Link>
                </div>
            )}
        </div>
    );
}

export default StudentDashboard;
