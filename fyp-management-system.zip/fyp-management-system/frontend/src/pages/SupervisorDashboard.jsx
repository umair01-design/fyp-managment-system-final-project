import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getAssignedProjects } from "../services/authService";
import { useAuth } from "../context/AuthContext";

const statusColor = { pending:"badge-yellow", approved:"badge-green", rejected:"badge-red", "in-progress":"badge-blue", completed:"badge-green" };

function SupervisorDashboard() {
    const { user } = useAuth();
    const [projects, setProjects] = useState([]);
    const [loading,  setLoading]  = useState(true);

    useEffect(() => {
        getAssignedProjects().then(r => setProjects(r.data)).catch(()=>{}).finally(()=>setLoading(false));
    }, []);

    const pending    = projects.filter(p => p.status === "pending");
    const approved   = projects.filter(p => p.status === "approved" || p.status === "in-progress");
    const completed  = projects.filter(p => p.status === "completed");

    if (loading) return <div className="page-loading">Loading dashboard...</div>;

    return (
        <div className="dashboard-container">
            <div className="page-header">
                <div>
                    <h1>Supervisor Dashboard</h1>
                    <p className="page-subtitle">Welcome, <strong>{user?.name}</strong></p>
                </div>
            </div>

            <div className="dashboard-cards">
                <div className="card"><div className="card-icon">📋</div><h3>Total Assigned</h3><p>{projects.length}</p></div>
                <div className="card"><div className="card-icon">⏳</div><h3>Pending Review</h3><p>{pending.length}</p></div>
                <div className="card"><div className="card-icon">🔄</div><h3>In Progress</h3><p>{approved.length}</p></div>
                <div className="card"><div className="card-icon">✅</div><h3>Completed</h3><p>{completed.length}</p></div>
            </div>

            <div className="dashboard-section">
                <h2>Assigned Projects</h2>
                {projects.length === 0 ? (
                    <div className="empty-state"><div className="empty-icon">📂</div><h3>No Projects Assigned Yet</h3><p>The admin will assign projects to you.</p></div>
                ) : (
                    <div className="table-wrapper">
                        <table>
                            <thead>
                                <tr><th>Project Title</th><th>Student</th><th>Domain</th><th>Status</th><th>Feedback</th><th>Action</th></tr>
                            </thead>
                            <tbody>
                                {projects.map(p => (
                                    <tr key={p._id}>
                                        <td><strong>{p.title}</strong></td>
                                        <td>{p.studentName}</td>
                                        <td>{p.domain}</td>
                                        <td><span className={`badge ${statusColor[p.status]}`}>{p.status}</span></td>
                                        <td>{p.feedback?.length || 0} comments</td>
                                        <td><Link to={`/project-review/${p._id}`} className="btn-sm">Review →</Link></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}

export default SupervisorDashboard;
