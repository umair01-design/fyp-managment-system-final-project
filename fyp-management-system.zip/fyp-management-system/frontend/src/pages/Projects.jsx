import DashboardLayout from "../components/DashboardLayout";

const projects = [
    { title: "FYP Management System",  student: "Ali Hassan",  supervisor: "Dr. Ahmed",  status: "In Progress", category: "Web App" },
    { title: "AI Chatbot Assistant",   student: "Usman Tariq", supervisor: "Dr. Sara",   status: "Submitted",   category: "AI/ML" },
    { title: "E-Commerce Platform",    student: "Hamza Ahmed", supervisor: "Dr. Bilal",  status: "Planning",    category: "Web App" },
    { title: "Data Analytics Tool",    student: "Bilal Khan",  supervisor: "Dr. Ahmed",  status: "In Progress", category: "Data Science" },
];

function Projects() {
    return (
        <DashboardLayout>
            <div className="dashboard-container">
                <div className="page-header">
                    <div>
                        <div className="page-badge">📁 Projects</div>
                        <h1>All Projects</h1>
                        <p className="text-muted">View and manage all Final Year Projects.</p>
                    </div>
                </div>

                <div className="dashboard-section">
                    <h2>📋 Project List</h2>
                    <div className="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Project Title</th>
                                    <th>Student</th>
                                    <th>Supervisor</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {projects.map((p, i) => (
                                    <tr key={i}>
                                        <td className="text-muted">{i + 1}</td>
                                        <td><strong>{p.title}</strong></td>
                                        <td>{p.student}</td>
                                        <td>{p.supervisor}</td>
                                        <td>
                                            <span className="badge badge-blue">{p.category}</span>
                                        </td>
                                        <td>
                                            <span className={`badge ${
                                                p.status === "Submitted"    ? "badge-green"  :
                                                p.status === "In Progress"  ? "badge-blue"   :
                                                "badge-yellow"
                                            }`}>
                                                {p.status}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}

export default Projects;
