import { useState, useEffect } from "react";
import { getStudents, deleteUser, updateUser } from "../services/authService";

function ManageStudents() {
    const [students, setStudents] = useState([]);
    const [editId,   setEditId]   = useState(null);
    const [editForm, setEditForm] = useState({ name:"", email:"" });
    const [search,   setSearch]   = useState("");
    const [error,  setError]  = useState("");
    const [success,setSuccess]= useState("");
    const [loading,setLoading]= useState(true);

    useEffect(() => {
        getStudents().then(r => setStudents(r.data)).catch(()=>{}).finally(()=>setLoading(false));
    }, []);

    const handleDelete = async (id) => {
        if (!window.confirm("Delete this student?")) return;
        try {
            await deleteUser(id);
            setStudents(prev => prev.filter(s => s._id !== id));
            setSuccess("Student deleted.");
        } catch (err) { setError("Delete failed."); }
    };

    const startEdit = (s) => { setEditId(s._id); setEditForm({ name: s.name, email: s.email }); };

    const handleUpdate = async (id) => {
        setError(""); setSuccess("");
        try {
            const r = await updateUser(id, editForm);
            setStudents(prev => prev.map(s => s._id === id ? r.data : s));
            setEditId(null); setSuccess("Student updated.");
        } catch (err) { setError("Update failed."); }
    };

    const filtered = students.filter(s =>
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.email.toLowerCase().includes(search.toLowerCase())
    );

    if (loading) return <div className="page-loading">Loading...</div>;

    return (
        <div className="page-wrapper">
            <div className="page-header">
                <div><h1>Manage Students</h1><p className="page-subtitle">{students.length} registered students</p></div>
            </div>
            {error   && <div className="error">⚠️ {error}</div>}
            {success && <div className="success-msg">✅ {success}</div>}

            <div className="filter-bar">
                <input type="text" placeholder="🔍 Search by name or email..." value={search} onChange={e=>setSearch(e.target.value)} className="search-input" />
            </div>

            <div className="table-wrapper">
                <table>
                    <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Actions</th></tr></thead>
                    <tbody>
                        {filtered.length === 0 ? (
                            <tr><td colSpan="4" style={{textAlign:"center",padding:"30px",color:"#94a3b8"}}>No students found.</td></tr>
                        ) : filtered.map((s, i) => (
                            <tr key={s._id}>
                                <td>{i+1}</td>
                                <td>{editId === s._id
                                    ? <input value={editForm.name} onChange={e=>setEditForm({...editForm,name:e.target.value})} className="inline-input" />
                                    : <strong>{s.name}</strong>}
                                </td>
                                <td>{editId === s._id
                                    ? <input value={editForm.email} onChange={e=>setEditForm({...editForm,email:e.target.value})} className="inline-input" />
                                    : s.email}
                                </td>
                                <td>
                                    {editId === s._id ? (
                                        <>
                                            <button className="btn-success-sm" onClick={()=>handleUpdate(s._id)}>Save</button>
                                            <button className="btn-cancel-sm"  onClick={()=>setEditId(null)}>Cancel</button>
                                        </>
                                    ) : (
                                        <>
                                            <button className="btn-sm"        onClick={()=>startEdit(s)}>Edit</button>
                                            <button className="btn-danger-sm" onClick={()=>handleDelete(s._id)}>Delete</button>
                                        </>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
export default ManageStudents;
