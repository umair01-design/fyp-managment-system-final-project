import { useState, useEffect } from "react";
import { getMyProgress, uploadProgress } from "../services/authService";

function WeeklyProgress() {
    const [updates, setUpdates] = useState([]);
    const [form, setForm] = useState({ weekNumber:"", description:"", achievement:"", nextPlan:"" });
    const [error,   setError]   = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        getMyProgress().then(r => setUpdates(r.data)).catch(() => {});
    }, []);

    const handleChange = e => setForm({...form, [e.target.name]: e.target.value});

    const handleSubmit = async e => {
        e.preventDefault();
        setError(""); setSuccess("");
        if (!form.weekNumber || !form.description)
            return setError("Week number and description are required.");
        setLoading(true);
        try {
            const r = await uploadProgress(form);
            setUpdates(prev => [...prev, r.data]);
            setForm({ weekNumber:"", description:"", achievement:"", nextPlan:"" });
            setSuccess("Progress update submitted successfully!");
        } catch (err) { setError(err.response?.data?.message || "Upload failed."); }
        finally { setLoading(false); }
    };

    return (
        <div className="page-wrapper">
            <div className="page-header">
                <div><h1>Weekly Progress</h1><p className="page-subtitle">Submit and track your weekly updates</p></div>
            </div>

            <div className="two-col-layout">
                <div className="form-card">
                    <div className="form-card-header"><h2>New Update</h2><p>Record your progress for this week</p></div>
                    {error   && <div className="error">⚠️ {error}</div>}
                    {success && <div className="success-msg">✅ {success}</div>}
                    <form onSubmit={handleSubmit}>
                        <div className="input-group">
                            <label>Week Number <span className="required">*</span></label>
                            <input type="number" name="weekNumber" min="1" max="20" placeholder="e.g. 1"
                                value={form.weekNumber} onChange={handleChange} />
                        </div>
                        <div className="input-group">
                            <label>What did you work on? <span className="required">*</span></label>
                            <textarea name="description" rows="3" placeholder="Describe your work this week..."
                                value={form.description} onChange={handleChange} />
                        </div>
                        <div className="input-group">
                            <label>Achievements</label>
                            <textarea name="achievement" rows="2" placeholder="What did you accomplish?"
                                value={form.achievement} onChange={handleChange} />
                        </div>
                        <div className="input-group">
                            <label>Plan for Next Week</label>
                            <textarea name="nextPlan" rows="2" placeholder="What will you do next week?"
                                value={form.nextPlan} onChange={handleChange} />
                        </div>
                        <button type="submit" className="btn-primary" style={{width:"100%"}} disabled={loading}>
                            {loading ? "Submitting..." : "Submit Update →"}
                        </button>
                    </form>
                </div>

                <div className="updates-panel">
                    <h2>All Updates ({updates.length})</h2>
                    {updates.length === 0 ? (
                        <div className="empty-state-sm"><p>No progress updates yet.</p></div>
                    ) : (
                        <div className="update-list">
                            {[...updates].reverse().map(u => (
                                <div key={u._id} className="update-card">
                                    <div className="update-week-badge">Week {u.weekNumber}</div>
                                    <p className="update-desc">{u.description}</p>
                                    {u.achievement && <p className="update-sub"><strong>✅ Achievement:</strong> {u.achievement}</p>}
                                    {u.nextPlan    && <p className="update-sub"><strong>📌 Next Week:</strong> {u.nextPlan}</p>}
                                    <span className="update-date">{new Date(u.createdAt).toLocaleDateString()}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default WeeklyProgress;
