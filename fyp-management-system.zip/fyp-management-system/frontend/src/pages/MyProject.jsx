import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getMyProject, editMyProject } from "../services/authService";

const DOMAINS = ["Artificial Intelligence","Web Development","Mobile App","Cybersecurity","Data Science","IoT","Cloud Computing","Blockchain","Other"];
const statusColor = { pending:"badge-yellow", approved:"badge-green", rejected:"badge-red", "in-progress":"badge-blue", completed:"badge-green" };

function MyProject() {
    const navigate = useNavigate();
    const [project, setProject] = useState(null);
    const [editing, setEditing] = useState(false);
    const [form,    setForm]    = useState({});
    const [error,   setError]   = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getMyProject()
            .then(r => { setProject(r.data); setForm(r.data); })
            .catch(() => navigate("/student"))
            .finally(() => setLoading(false));
    }, []);

    const handleChange = e => setForm({...form, [e.target.name]: e.target.value});

    const handleSave = async e => {
        e.preventDefault();
        setError(""); setSuccess("");
        try {
            const r = await editMyProject(form);
            setProject(r.data); setEditing(false);
            setSuccess("Project updated successfully!");
        } catch (err) { setError(err.response?.data?.message || "Update failed."); }
    };

    if (loading) return <div className="page-loading">Loading...</div>;
    if (!project) return null;

    return (
        <div className="page-wrapper">
            <div className="page-header">
                <div>
                    <h1>My Project</h1>
                    <p className="page-subtitle">View and manage your FYP proposal</p>
                </div>
                {project.status === "pending" && !editing && (
                    <button className="btn-primary" onClick={() => setEditing(true)}>✏️ Edit Proposal</button>
                )}
            </div>

            {error   && <div className="error">⚠️ {error}</div>}
            {success && <div className="success-msg">✅ {success}</div>}

            {!editing ? (
                <div className="detail-card">
                    <div className="detail-card-header">
                        <h2>{project.title}</h2>
                        <span className={`badge ${statusColor[project.status]}`}>{project.status}</span>
                    </div>
                    <div className="detail-grid">
                        <div className="detail-item"><label>Domain</label><span>{project.domain}</span></div>
                        <div className="detail-item"><label>Technologies</label><span>{project.technologies}</span></div>
                        <div className="detail-item"><label>Team Members</label><span>{project.teamMembers}</span></div>
                        <div className="detail-item"><label>Supervisor</label><span>{project.supervisorName || "Not Assigned Yet"}</span></div>
                        <div className="detail-item full-width"><label>Description</label><span>{project.description}</span></div>
                    </div>

                    {project.feedback?.length > 0 && (
                        <div className="feedback-section">
                            <h3>Supervisor Feedback</h3>
                            {project.feedback.map((f, i) => (
                                <div key={i} className="feedback-card">
                                    <div className="feedback-header">
                                        <strong>👨‍🏫 {f.supervisorName}</strong>
                                        <span>{new Date(f.createdAt).toLocaleDateString()}</span>
                                    </div>
                                    <p>{f.comment}</p>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            ) : (
                <div className="form-card">
                    <h2>Edit Project Proposal</h2>
                    <form onSubmit={handleSave}>
                        <div className="input-group">
                            <label>Project Title</label>
                            <input type="text" name="title" value={form.title||""} onChange={handleChange} />
                        </div>
                        <div className="input-group">
                            <label>Domain</label>
                            <select name="domain" value={form.domain||""} onChange={handleChange}>
                                {DOMAINS.map(d => <option key={d} value={d}>{d}</option>)}
                            </select>
                        </div>
                        <div className="input-group">
                            <label>Description</label>
                            <textarea name="description" rows="5" value={form.description||""} onChange={handleChange} />
                        </div>
                        <div className="input-group">
                            <label>Technologies</label>
                            <input type="text" name="technologies" value={form.technologies||""} onChange={handleChange} />
                        </div>
                        <div className="input-group">
                            <label>Team Members</label>
                            <input type="text" name="teamMembers" value={form.teamMembers||""} onChange={handleChange} />
                        </div>
                        <div className="form-actions">
                            <button type="button" className="btn-cancel" onClick={() => setEditing(false)}>Cancel</button>
                            <button type="submit" className="btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            )}
        </div>
    );
}

export default MyProject;
