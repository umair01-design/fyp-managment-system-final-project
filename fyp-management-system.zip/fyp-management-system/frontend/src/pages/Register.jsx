import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { registerUser } from "../services/authService";

function Register() {
    const navigate  = useNavigate();
    const [formData, setFormData] = useState({
        name: "", email: "", password: "", confirmPassword: "", role: "student"
    });
    const [error,   setError]   = useState("");
    const [success, setSuccess] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const validate = () => {
        const { name, email, password, confirmPassword } = formData;
        if (!name.trim())  return "Full name is required.";
        if (!email.trim()) return "Email address is required.";
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) return "Please enter a valid email address.";
        if (!password)     return "Password is required.";
        if (password.length < 6) return "Password must be at least 6 characters.";
        if (password !== confirmPassword) return "Passwords do not match.";
        return null;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        const validationError = validate();
        if (validationError) { setError(validationError); return; }

        setLoading(true);
        try {
            const { confirmPassword, ...dataToSend } = formData;
            await registerUser(dataToSend);
            setSuccess(true);
            setTimeout(() => navigate("/login"), 1800);
        } catch (err) {
            setError(err.response?.data?.message || "Registration failed. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-container">
            <form className="auth-form" onSubmit={handleSubmit}>
                <div className="auth-logo">
                    <div className="auth-logo-icon">✨</div>
                    <h2>Create Account</h2>
                    <p className="auth-subtitle">Join the FYP Management System</p>
                </div>

                {error   && <div className="error">⚠️ {error}</div>}
                {success && <div className="success-msg">✅ Registered successfully! Redirecting...</div>}

                <div className="input-group">
                    <label>Full Name</label>
                    <input
                        type="text"
                        name="name"
                        placeholder="Your full name"
                        value={formData.name}
                        onChange={handleChange}
                    />
                </div>

                <div className="input-group">
                    <label>Email Address</label>
                    <input
                        type="email"
                        name="email"
                        placeholder="you@university.edu"
                        value={formData.email}
                        onChange={handleChange}
                    />
                </div>

                <div className="input-group">
                    <label>Password <span style={{color:"#94a3b8", fontSize:"12px"}}>(min. 6 characters)</span></label>
                    <input
                        type="password"
                        name="password"
                        placeholder="Create a strong password"
                        value={formData.password}
                        onChange={handleChange}
                    />
                </div>

                <div className="input-group">
                    <label>Confirm Password</label>
                    <input
                        type="password"
                        name="confirmPassword"
                        placeholder="Repeat your password"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                    />
                </div>

                <div className="input-group">
                    <label>Role</label>
                    <select name="role" onChange={handleChange} value={formData.role}>
                        <option value="student">🎓 Student</option>
                        <option value="supervisor">👨‍🏫 Supervisor</option>
                    </select>
                </div>

                <button type="submit" disabled={loading || success}>
                    {loading ? "Creating account..." : "Create Account →"}
                </button>

                <p className="auth-link">
                    Already have an account? <Link to="/login">Sign in</Link>
                </p>
            </form>
        </div>
    );
}

export default Register;
