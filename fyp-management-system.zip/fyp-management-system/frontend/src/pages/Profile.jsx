import DashboardLayout from "../components/DashboardLayout";
import { useAuth } from "../context/AuthContext";

function Profile() {
    const { user } = useAuth();

    const getRoleBadge = (role) => {
        if (role === "admin")      return "badge badge-red";
        if (role === "supervisor") return "badge badge-yellow";
        return "badge badge-blue";
    };

    return (
        <DashboardLayout>
            <div className="dashboard-container">
                <div className="page-header">
                    <div>
                        <div className="page-badge">👤 Account</div>
                        <h1>My Profile</h1>
                        <p className="text-muted">Your personal account information.</p>
                    </div>
                </div>

                {user && (
                    <>
                        <div className="profile-hero-card">
                            <div className="profile-avatar-lg">
                                {user.name?.charAt(0).toUpperCase()}
                            </div>
                            <div className="profile-hero-info">
                                <h2>{user.name}</h2>
                                <p>{user.email}</p>
                                <span className={getRoleBadge(user.role)}>
                                    {user.role?.toUpperCase()}
                                </span>
                            </div>
                        </div>

                        <div className="dashboard-section">
                            <h2>📋 Account Details</h2>
                            <div className="profile-info">
                                <div className="profile-row">
                                    <strong>Full Name</strong>
                                    <span>{user.name}</span>
                                </div>
                                <div className="profile-row">
                                    <strong>Email</strong>
                                    <span>{user.email}</span>
                                </div>
                                <div className="profile-row">
                                    <strong>Role</strong>
                                    <span className={getRoleBadge(user.role)}>
                                        {user.role?.toUpperCase()}
                                    </span>
                                </div>
                                <div className="profile-row">
                                    <strong>Status</strong>
                                    <span className="badge badge-green">Active</span>
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </div>
        </DashboardLayout>
    );
}

export default Profile;
