import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getAllProjects, getStudents, getSupervisors } from "../services/authService";
import { useAuth } from "../context/AuthContext";

const statusColor = { pending:"badge-yellow", approved:"badge-green", rejected:"badge-red", "in-progress":"badge-blue", completed:"badge-green" };

function AdminDashboard() {
    const { user } = useAuth();
    const [projects,     setProjects]     = useState([]);
    const [students,     setStudents]     = useState([]);
    const [supervisors,  setSupervisors]  = useState([]);
    const [loading,      setLoading]      = useState(true);

    useEffect(() => {
        Promise.all([getAllProjects(), getStudents(), getSupervisors()])
            .then(([p, s, sv]) => {
                setProjects(p.data); setStudents(s.data); setSupervisors(sv.data);
            }).catch(()=>{}).finally(()=>setLoading(false));
    }, []);

    const pending   = projects.filter(p => p.status === "pending").length;
    const approved  = projects.filter(p => p.status === "approved" || p.status === "in-progress").length;
    const completed = projects.filter(p => p.status === "completed").length;

    if (loading) return <div className="page-loading">Loading dashboard...</div>;

    return (
        <div className="dashboard-container">
            <div className="page-header">
                <div><h1>Admin Dashboard</h1><p className="page-subtitle">Welcome, <strong>{user?.name}</strong> — System Overview</p></div>
            </div>

            <div className="dashboard-cards">
                <div className="card"><div className="card-icon">🎓</div><h3>Total Students</h3><p>{students.length}</p></div>
                <div className="card"><div className="card-icon">👨‍🏫</div><h3>Total Supervisors</h3><p>{supervisors.length}</p></div>
                <div className="card"><div className="card-icon">📋</div><h3>Total Projects</h3><p>{projects.length}</p></div>
                <div className="card"><div className="card-icon">⏳</div><h3>Pending Review</h3><p>{pending}</p></div>
                <div className="card"><div className="card-icon">🔄</div><h3>In Progress</h3><p>{approved}</p></div>
                <div className="card"><div className="card-icon">✅</div><h3>Completed</h3><p>{completed}</p></div>
            </div>

            <div className="admin-quick-actions">
                <Link to="/manage-students"    className="quick-action-card"><div className="qa-icon">🎓</div><h3>Manage Students</h3><p>View, edit or remove student accounts</p></Link>
                <Link to="/manage-supervisors" className="quick-action-card"><div className="qa-icon">👨‍🏫</div><h3>Manage Supervisors</h3><p>View, edit or remove supervisor accounts</p></Link>
                <Link to="/all-projects"       className="quick-action-card"><div className="qa-icon">📋</div><h3>All Projects</h3><p>View all projects and assign supervisors</p></Link>
            </div>

            <div className="dashboard-section">
                <h2>Recent Projects</h2>
                {projects.length === 0 ? (
                    <div className="empty-state-sm"><p>No projects submitted yet.</p></div>
                ) : (
                    <div className="table-wrapper">
                        <table>
                            <thead><tr><th>Title</th><th>Student</th><th>Domain</th><th>Supervisor</th><th>Status</th></tr></thead>
                            <tbody>
                                {projects.slice(0,8).map(p => (
                                    <tr key={p._id}>
                                        <td><strong>{p.title}</strong></td>
                                        <td>{p.studentName}</td>
                                        <td>{p.domain}</td>
                                        <td>{p.supervisorName || <span style={{color:"#94a3b8"}}>Not Assigned</span>}</td>
                                        <td><span className={`badge ${statusColor[p.status]}`}>{p.status}</span></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
                <Link to="/all-projects" className="btn-link" style={{marginTop:"12px"}}>View All Projects →</Link>
            </div>
        </div>
    );
}
export default AdminDashboard;
