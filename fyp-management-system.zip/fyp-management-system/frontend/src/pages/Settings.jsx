import DashboardLayout from "../components/DashboardLayout";

function Settings() {
    return (
        <DashboardLayout>
            <div className="dashboard-container">
                <div className="page-header">
                    <div>
                        <div className="page-badge">⚙️ System</div>
                        <h1>Settings</h1>
                        <p className="text-muted">Manage your account preferences.</p>
                    </div>
                </div>

                <div className="dashboard-section">
                    <h2>🔔 Notifications</h2>
                    <div className="settings-row">
                        <div>
                            <strong>Email Notifications</strong>
                            <p className="text-muted">Receive updates about your projects</p>
                        </div>
                        <label className="toggle">
                            <input type="checkbox" defaultChecked />
                            <span className="toggle-slider" />
                        </label>
                    </div>
                    <div className="settings-row">
                        <div>
                            <strong>Meeting Reminders</strong>
                            <p className="text-muted">Get reminded before scheduled meetings</p>
                        </div>
                        <label className="toggle">
                            <input type="checkbox" defaultChecked />
                            <span className="toggle-slider" />
                        </label>
                    </div>
                </div>

                <div className="dashboard-section">
                    <h2>🔒 Security</h2>
                    <div className="settings-row">
                        <div>
                            <strong>Change Password</strong>
                            <p className="text-muted">Update your account password</p>
                        </div>
                        <button className="btn btn-ghost btn-sm">Update</button>
                    </div>
                    <div className="settings-row">
                        <div>
                            <strong>Two-Factor Auth</strong>
                            <p className="text-muted">Add an extra layer of security</p>
                        </div>
                        <button className="btn btn-ghost btn-sm">Enable</button>
                    </div>
                </div>

                <div className="dashboard-section">
                    <h2>🎨 Preferences</h2>
                    <div className="settings-row">
                        <div>
                            <strong>Language</strong>
                            <p className="text-muted">Choose your preferred language</p>
                        </div>
                        <select className="settings-select">
                            <option>English</option>
                            <option>Urdu</option>
                        </select>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}

export default Settings;
