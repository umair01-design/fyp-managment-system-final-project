import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function Home() {
    const { user } = useAuth();

    const getDashboardLink = (role) => {
        if (user) {
            if (user.role === role) return `/${role}`;
            return "/";
        }
        return "/login";
    };

    return (
        <div className="home-container">
            <div className="hero">
                <div className="hero-badge">🎓 Final Year Project System</div>
                <h1>Final Year Project <em>Management System</em></h1>
                <p>
                    Manage Students, Supervisors and Projects Efficiently Through One Platform.
                </p>
                <div className="hero-cta">
                    <Link to="/register" className="btn-primary">Get Started →</Link>
                    <Link to="/login"    className="btn-outline">Sign In</Link>
                </div>
                <div className="hero-stats">
                    <div className="hero-stat">
                        <strong>120+</strong>
                        <span>Students</span>
                    </div>
                    <div className="hero-stat-divider" />
                    <div className="hero-stat">
                        <strong>20+</strong>
                        <span>Supervisors</span>
                    </div>
                    <div className="hero-stat-divider" />
                    <div className="hero-stat">
                        <strong>95+</strong>
                        <span>Projects</span>
                    </div>
                </div>
            </div>

            <div className="section-title">
                <h2>Choose your role</h2>
                <p>Click your role to sign in and access your dashboard</p>
            </div>

            <div className="feature-grid">

                <Link to="/student" className="feature-card feature-card-link">
                    <div className="feature-icon">🎓</div>
                    <h3>Students</h3>
                    <p>Manage project submissions and progress updates.</p>
                    <span className="feature-card-cta">Go to Student Dashboard →</span>
                </Link>

                <Link to="/supervisor" className="feature-card feature-card-link">
                    <div className="feature-icon">👨‍🏫</div>
                    <h3>Supervisors</h3>
                    <p>Monitor assigned students and project activities.</p>
                    <span className="feature-card-cta">Go to Supervisor Dashboard →</span>
                </Link>

                <Link to="/admin" className="feature-card feature-card-link">
                    <div className="feature-icon">🛡️</div>
                    <h3>Admin</h3>
                    <p>Control users and manage the complete system.</p>
                    <span className="feature-card-cta">Go to Admin Dashboard →</span>
                </Link>

            </div>
        </div>
    );
}

export default Home;
