import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function Navbar() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const getDashLink = () => {
        if (!user) return "/login";
        return user.role === "student" ? "/student"
             : user.role === "supervisor" ? "/supervisor"
             : "/admin";
    };

    return (
        <nav className="navbar">
            <Link to="/" className="navbar-brand">
                🎓 <span>FYP</span> Management System
            </Link>
            <div className="navbar-links">
                {!user ? (
                    <>
                        <Link to="/"         className="navbar-link">Home</Link>
                        <Link to="/login"    className="navbar-btn">Login</Link>
                        <Link to="/register" className="navbar-btn navbar-btn-outline">Register</Link>
                    </>
                ) : (
                    <>
                        <Link to={getDashLink()} className="navbar-link">Dashboard</Link>
                        <div className="navbar-user">
                            <span className="navbar-avatar">{user.name?.charAt(0).toUpperCase()}</span>
                            <span className="navbar-username">{user.name}</span>
                        </div>
                        <button className="navbar-logout" onClick={() => { logout(); navigate("/login"); }}>
                            Logout
                        </button>
                    </>
                )}
            </div>
        </nav>
    );
}
export default Navbar;
