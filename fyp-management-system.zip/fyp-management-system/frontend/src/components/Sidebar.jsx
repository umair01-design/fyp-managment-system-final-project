import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const studentLinks = [
    { to: "/student",         icon: "🏠", label: "Dashboard" },
    { to: "/submit-proposal", icon: "📝", label: "Submit Proposal" },
    { to: "/my-project",      icon: "📋", label: "My Project" },
    { to: "/weekly-progress", icon: "📅", label: "Weekly Progress" },
    { to: "/profile",         icon: "👤", label: "Profile" },
];
const supervisorLinks = [
    { to: "/supervisor", icon: "🏠", label: "Dashboard" },
    { to: "/profile",    icon: "👤", label: "Profile" },
];
const adminLinks = [
    { to: "/admin",             icon: "🏠", label: "Dashboard" },
    { to: "/all-projects",      icon: "📋", label: "All Projects" },
    { to: "/manage-students",   icon: "🎓", label: "Students" },
    { to: "/manage-supervisors",icon: "👨‍🏫", label: "Supervisors" },
    { to: "/profile",           icon: "👤", label: "Profile" },
];

function Sidebar() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    if (!user) return null;

    const links = user.role === "student" ? studentLinks
                : user.role === "supervisor" ? supervisorLinks
                : adminLinks;

    const handleLogout = () => { logout(); navigate("/login"); };

    const roleLabel = user.role === "student" ? "🎓 Student"
                    : user.role === "supervisor" ? "👨‍🏫 Supervisor"
                    : "🛡️ Admin";

    return (
        <aside className="sidebar">
            <div className="sidebar-header">
                <div className="sidebar-logo">FYP System</div>
                <div className="sidebar-user">
                    <div className="sidebar-avatar">{user.name?.charAt(0).toUpperCase()}</div>
                    <div>
                        <div className="sidebar-name">{user.name}</div>
                        <div className="sidebar-role">{roleLabel}</div>
                    </div>
                </div>
            </div>

            <nav className="sidebar-links">
                {links.map(link => (
                    <NavLink key={link.to} to={link.to}
                        className={({ isActive }) => `sidebar-link${isActive ? " active" : ""}`}
                    >
                        <span className="sidebar-link-icon">{link.icon}</span>
                        <span>{link.label}</span>
                    </NavLink>
                ))}
            </nav>

            <button className="sidebar-logout" onClick={handleLogout}>
                🚪 Logout
            </button>
        </aside>
    );
}
export default Sidebar;
