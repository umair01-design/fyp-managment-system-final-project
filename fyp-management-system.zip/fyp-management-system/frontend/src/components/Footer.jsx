function Footer() {
    return (
        <footer className="footer">
            <div className="footer-content">
                <div className="footer-logo">🎓</div>
                <h3>FYP Management System</h3>
                <div className="footer-divider" />
                <p>Manage Projects, Students and Supervisors Efficiently.</p>
                <p className="footer-copy">© 2026 FYP Management System. All Rights Reserved.</p>
            </div>
        </footer>
    );
}

export default Footer;
