import axios from "axios";

const API      = "/api/auth";
const PROJ_API = "/api/projects";
const PROG_API = "/api/progress";
const ADM_API  = "/api/admin";

const authHeader = () => ({
    headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
});

// ── AUTH ──────────────────────────────────────────────────
export const registerUser = (data) => axios.post(`${API}/register`, data);
export const loginUser    = (data) => axios.post(`${API}/login`, data);
export const getMe        = ()     => axios.get(`${API}/me`, authHeader());

// ── STUDENT ───────────────────────────────────────────────
export const submitProposal  = (data) => axios.post(`${PROJ_API}/submit`,    data, authHeader());
export const getMyProject    = ()     => axios.get(`${PROJ_API}/mine`,             authHeader());
export const editMyProject   = (data) => axios.put(`${PROJ_API}/mine/edit`,  data, authHeader());
export const getMyProgress   = ()     => axios.get(`${PROG_API}/mine`,             authHeader());
export const uploadProgress  = (data) => axios.post(`${PROG_API}/upload`,    data, authHeader());

// ── SUPERVISOR ────────────────────────────────────────────
export const getAssignedProjects   = ()          => axios.get(`${PROJ_API}/assigned`,           authHeader());
export const updateProjectStatus   = (id, data)  => axios.put(`${PROJ_API}/${id}/status`, data, authHeader());
export const addFeedback           = (id, data)  => axios.post(`${PROJ_API}/${id}/feedback`,data, authHeader());
export const getProgressByProject  = (id)        => axios.get(`${PROG_API}/${id}`,              authHeader());

// ── ADMIN ─────────────────────────────────────────────────
export const getAllProjects         = ()          => axios.get(`${PROJ_API}/all`,                authHeader());
export const assignSupervisor      = (id, data)  => axios.put(`${PROJ_API}/${id}/assign-supervisor`, data, authHeader());
export const deleteProject         = (id)        => axios.delete(`${PROJ_API}/${id}`,           authHeader());
export const getStudents           = ()          => axios.get(`${ADM_API}/students`,             authHeader());
export const getSupervisors        = ()          => axios.get(`${ADM_API}/supervisors`,          authHeader());
export const deleteUser            = (id)        => axios.delete(`${ADM_API}/users/${id}`,       authHeader());
export const updateUser            = (id, data)  => axios.put(`${ADM_API}/users/${id}`,    data, authHeader());
